﻿namespace TaskBoard.WebAPI.Models.Response
{
    public class ResponseMsg
    {
        public string Message { get; init; }
    }
}
