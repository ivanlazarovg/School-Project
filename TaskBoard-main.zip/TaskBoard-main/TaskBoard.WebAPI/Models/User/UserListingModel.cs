namespace TaskBoard.WebAPI.Models.User
{
    public class UserListingModel
    {
        public string Id { get; init; }
        public string FirstName { get; init; }
        public string LastName { get; init; }
        public string Username { get; init; }
        public string Email { get; init; }
    }
}