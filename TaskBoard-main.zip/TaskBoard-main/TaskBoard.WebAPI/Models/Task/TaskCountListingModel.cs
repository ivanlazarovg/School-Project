﻿namespace TaskBoard.WebAPI.Models.Task
{
    public class TaskCountListingModel
    {
        public string BoardName { get; init; }
        public int TasksCount { get; init; }
    }
}
