﻿namespace TaskBoard.WebAPI.Models.Task
{
    public class TaskListingModel
    {
        public int Id { get; init; }
        public string Title { get; init; }
        public string Description { get; init; }
    }
}
