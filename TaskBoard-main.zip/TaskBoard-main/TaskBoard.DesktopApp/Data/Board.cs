﻿namespace TaskBoard.DesktopApp.Data
{
    public class Board
    {
        public int Id { get; init; }
        public string Name { get; init; }
    }
}