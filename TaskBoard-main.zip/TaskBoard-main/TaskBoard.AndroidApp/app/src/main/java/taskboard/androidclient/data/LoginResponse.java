package taskboard.androidclient.data;

public class LoginResponse {
    private String token;

    public String getToken() { return token; }
}
