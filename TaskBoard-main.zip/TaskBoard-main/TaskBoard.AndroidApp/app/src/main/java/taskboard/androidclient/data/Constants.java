package taskboard.androidclient.data;

public final class Constants {
    public static final int MinTitleLength = 5;
    public static final int MinDescriptionLength = 10;
    public static final int MinPasswordLength = 6;
}
