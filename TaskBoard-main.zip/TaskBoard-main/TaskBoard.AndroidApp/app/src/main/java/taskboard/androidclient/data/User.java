package taskboard.androidclient.data;

public class User {
    private String id;
    private String username;

    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }
}
