package taskboard.androidclient.data;

public class Board {
    private String name;

    public String getName() {
        return name;
    }
}
